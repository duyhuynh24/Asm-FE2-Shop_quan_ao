import HeaderUser from '../../components/HeaderUser';
import FooterUser from '../../components/FooterUser';
import { Link } from 'react-router-dom';

const Order = () => {
    return (
        <div className="container">
            {/* Order List Start */}
            <div className="container-fluid pt-4 px-4">
                <div className="row bg-secondary rounded p-4 mx-0">
                    <div className="col-md-12">
                        <h2 className="text-center text-white mb-4">Danh Sách Đơn Hàng</h2>
                        <div className="table-responsive">
                            <table className="table table-dark table-bordered text-center">
                                <thead className="bg-primary text-white">
                                    <tr>
                                        <th>ID</th>
                                        <th>Khách hàng</th>
                                        <th>Ngày đặt</th>
                                        <th>Tổng tiền</th>
                                        <th>Trạng thái</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>DH001</td>
                                        <td>Nguyễn Văn A</td>
                                        <td>2025-03-28</td>
                                        <td>1.200.000đ</td>
                                        <td><span className="badge bg-success">Hoàn thành</span></td>
                                    </tr>
                                    <tr>
                                        <td>DH002</td>
                                        <td>Trần Thị B</td>
                                        <td>2025-03-27</td>
                                        <td>750.000đ</td>
                                        <td><span className="badge bg-warning text-dark">Chưa hoàn thành</span></td>
                                    </tr>
                                    <tr>
                                        <td>DH003</td>
                                        <td>Phạm Văn C</td>
                                        <td>2025-03-26</td>
                                        <td>2.500.000đ</td>
                                        <td><span className="badge bg-success">Hoàn thành</span></td>
                                    </tr>
                                    <tr>
                                        <td>DH004</td>
                                        <td>Lê Thị D</td>
                                        <td>2025-03-25</td>
                                        <td>950.000đ</td>
                                        <td><span className="badge bg-warning text-dark">Chưa hoàn thành</span></td>
                                    </tr>
                                    {/* Thêm đơn hàng khác tại đây */}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            {/* Order List End */}
        </div>
    );
};

export default Order;
