import HeaderUser from '../../components/HeaderUser';
import FooterUser from '../../components/FooterUser';
import { Link } from 'react-router-dom';

const Product = () => {
    return (
        <div className="container">
            {/* Product List Start */}
            <div className="container-fluid pt-4 px-4">
                <div className="row bg-secondary rounded p-4 mx-0">
                    <div className="col-md-12">
                        <h2 className="text-center text-white mb-4">Danh Sách Sản Phẩm</h2>
                        <div className="d-flex align-items-center justify-content-between mb-4">
                            <Link to="/add-product" className="btn btn-primary ms-auto">Thêm Sản Phẩm</Link>
                        </div>
                        <div className="table-responsive">
                            <table className="table table-dark table-bordered text-center">
                                <thead className="bg-primary text-white">
                                    <tr>
                                        <th>ID</th>
                                        <th>Tên sản phẩm</th>
                                        <th>Giá</th>
                                        <th>Mô tả</th>
                                        <th>Hoạt động</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>Áo Hoodie Nam</td>
                                        <td>350,000đ</td>
                                        <td>Chất vải nỉ bông, co giãn</td>
                                        <td>
                                            <Link to="/edit-product/1" className="btn btn-sm btn-primary">
                                                <i className="fas fa-edit"></i> Sửa
                                            </Link>
                                            <button className="btn btn-sm btn-danger">
                                                <i className="fas fa-trash"></i> Xóa
                                            </button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>Quần Jean Slimfit</td>
                                        <td>420,000đ</td>
                                        <td>Vải denim cao cấp</td>
                                        <td>
                                            <Link to="/edit-product/2" className="btn btn-sm btn-primary">
                                                <i className="fas fa-edit"></i> Sửa
                                            </Link>
                                            <button className="btn btn-sm btn-danger">
                                                <i className="fas fa-trash"></i> Xóa
                                            </button>
                                        </td>
                                    </tr>
                                    {/* Thêm các sản phẩm khác tại đây */}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            {/* Product List End */}
        </div>
    );
};

export default Product;
