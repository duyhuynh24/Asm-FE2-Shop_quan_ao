import HeaderUser from '../../components/HeaderUser';
import FooterUser from '../../components/FooterUser';
import { Link } from 'react-router-dom';

const Comment = () => {
    return (
        <div className="container">
            <div className="container-fluid pt-4 px-4">
                <div className="bg-secondary text-center rounded p-4">
                    <div className="d-flex align-items-center justify-content-between mb-4">
                        <h2 className="mb-0">Danh Sách Bình Luận</h2>
                    </div>
                    <div className="table-responsive">
                        <table className="table text-start align-middle table-bordered table-hover mb-0">
                            <thead>
                                <tr className="text-white">
                                    <th scope="col">ID</th>
                                    <th scope="col">Tên Người Dùng</th>
                                    <th scope="col">Bình Luận</th>
                                    <th scope="col">Trạng Thái</th>
                                    <th scope="col">Hoạt Động</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>Nguyễn Văn A</td>
                                    <td>Sản phẩm rất tốt!</td>
                                    <td>Hiển thị</td>
                                    <td>
                                        <button className="btn btn-sm btn-warning d-flex align-items-center">
                                            <i className="fa fa-edit me-2"></i>Sửa
                                        </button>
                                        <button className="btn btn-sm btn-danger d-flex align-items-center">
                                            <i className="fa fa-trash me-2"></i>Xóa
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Trần Thị B</td>
                                    <td>Giao hàng nhanh, đóng gói cẩn thận.</td>
                                    <td>Ẩn</td>
                                    <td>
                                        <button className="btn btn-sm btn-warning d-flex align-items-center">
                                            <i className="fa fa-edit me-2"></i>Sửa
                                        </button>
                                        <button className="btn btn-sm btn-danger d-flex align-items-center">
                                            <i className="fa fa-trash me-2"></i>Xóa
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Comment;
