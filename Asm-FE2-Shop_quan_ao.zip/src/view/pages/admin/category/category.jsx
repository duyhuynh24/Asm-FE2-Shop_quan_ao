import HeaderUser from '../../components/HeaderUser';
import FooterUser from '../../components/FooterUser';
import { Link } from 'react-router-dom';

const Category = () => {
    return (
        <div className="container">
            {/* Category List Start */}
            <div className="container-fluid pt-4 px-4">
                <div className="row bg-secondary rounded p-4 mx-0">
                    <div className="col-md-12">
                        <div className="d-flex align-items-center justify-content-between mb-4">
                            <h2 className="text-center text-white mb-4">Danh Sách Loại Sản Phẩm</h2>
                            <Link to="/add-category" className="btn btn-primary">Thêm Loại Sản Phẩm</Link>
                        </div>

                        <div className="table-responsive">
                            <table className="table table-dark table-bordered text-center">
                                <thead className="bg-primary text-white">
                                    <tr>
                                        <th>ID</th>
                                        <th>Tên loại</th>
                                        <th>Mô tả</th>
                                        <th>Trạng thái</th>
                                        <th>Hoạt động</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>Áo Nam</td>
                                        <td>Các loại áo nam thời trang</td>
                                        <td><span className="badge bg-success">Đang kinh doanh</span></td>
                                        <td>
                                            <Link to="/edit-category/1" className="btn btn-sm btn-primary">
                                                <i className="fas fa-edit"></i> Sửa
                                            </Link>
                                            <button className="btn btn-sm btn-danger">
                                                <i className="fas fa-trash"></i> Xóa
                                            </button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>Quần Nam</td>
                                        <td>Quần jeans, kaki, thể thao</td>
                                        <td><span className="badge bg-danger">Ngừng kinh doanh</span></td>
                                        <td>
                                            <Link to="/edit-category/2" className="btn btn-sm btn-primary">
                                                <i className="fas fa-edit"></i> Sửa
                                            </Link>
                                            <button className="btn btn-sm btn-danger">
                                                <i className="fas fa-trash"></i> Xóa
                                            </button>
                                        </td>
                                    </tr>
                                    {/* Thêm các loại sản phẩm khác tại đây */}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            {/* Category List End */}
        </div>
    );
}

export default Category;
