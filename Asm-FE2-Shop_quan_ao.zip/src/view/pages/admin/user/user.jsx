import HeaderUser from '../../components/HeaderUser';
import FooterUser from '../../components/FooterUser';
import { Link } from 'react-router-dom';

const User = () => {
    return (
        <div className="container">
            
            
            <div className="container-fluid pt-4 px-4">
                <div className="bg-secondary text-center rounded p-4">
                    <div className="d-flex align-items-center justify-content-between mb-4">
                        <h2 className="mb-0">Danh Sách Người Dùng</h2>
                    </div>
                    <div className="table-responsive">
                        <table className="table text-start align-middle table-bordered table-hover mb-0">
                            <thead>
                                <tr className="text-white">
                                    <th scope="col">ID</th>
                                    <th scope="col">Tên</th>
                                    <th scope="col">Mật Khẩu</th>
                                    <th scope="col">Số Điện Thoại</th>
                                    <th scope="col">Gmail</th>
                                    <th scope="col">Địa Chỉ</th>
                                    <th scope="col">Hoạt Động</th>
                                </tr>
                            </thead>
                            <tbody>
                                {[
                                    {
                                        id: 1,
                                        name: "Nguyễn Văn A",
                                        phone: "0123456789",
                                        email: "email@example.com",
                                        address: "Hà Nội",
                                    },
                                    {
                                        id: 2,
                                        name: "Trần Thị B",
                                        phone: "0987654321",
                                        email: "email2@example.com",
                                        address: "TP.HCM",
                                    },
                                ].map((user) => (
                                    <tr key={user.id}>
                                        <td>{user.id}</td>
                                        <td>{user.name}</td>
                                        <td>********</td>
                                        <td>{user.phone}</td>
                                        <td>{user.email}</td>
                                        <td>{user.address}</td>
                                        <td>
                                            <button className="btn btn-sm btn-primary">
                                                <i className="fas fa-edit"></i> Sửa
                                            </button>
                                            <button className="btn btn-sm btn-danger ms-2">
                                                <i className="fas fa-trash"></i> Xóa
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

           
        </div>
    );
};

export default User;
