import HeaderUser from '../../components/HeaderUser';
import FooterUser from '../../components/FooterUser';
import { Link } from 'react-router-dom';

const SignIn = () => {
    return (
        <div className="container">


            {/* Sign In Start */}
            <div className="container-fluid">
                <div
                    className="row h-100 align-items-center justify-content-center"
                    style={{ minHeight: "100vh" }}
                >
                    <div className="col-12 col-sm-8 col-md-6 col-lg-5 col-xl-4">
                        <div className="bg-secondary rounded p-4 p-sm-5 my-4 mx-3">
                            <div className="d-flex align-items-center justify-content-between mb-3">
                                <Link to="/" className="text-decoration-none">
                                    <h3 className="text-primary">
                                        <i className="fa fa-user-edit me-2"></i> ADMIN
                                    </h3>
                                </Link>
                                <h3>Đăng Nhập</h3>
                            </div>
                            <div className="form-floating mb-3">
                                <input
                                    type="email"
                                    className="form-control"
                                    id="floatingInput"
                                    placeholder="name@example.com"
                                />
                                <label htmlFor="floatingInput">Email address</label>
                            </div>
                            <div className="form-floating mb-4">
                                <input
                                    type="password"
                                    className="form-control"
                                    id="floatingPassword"
                                    placeholder="Password"
                                />
                                <label htmlFor="floatingPassword">Password</label>
                            </div>
                            <div className="d-flex align-items-center justify-content-between mb-4">
                                <Link to="/forgot-password">Forgot Password</Link>
                            </div>
                            <button type="submit" className="btn btn-primary py-3 w-100 mb-4">
                                Đăng Nhập
                            </button>
                            <Link to="/" className="btn btn-primary py-3 w-100 mb-4">
                                Trở về
                            </Link>
                            <p className="text-center mb-0">
                                Bạn Chưa Có Tài Khoản?{" "}
                                <Link to="/signup">Đăng Kí</Link>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            {/* Sign In End */}

            
        </div>
    );
};

export default SignIn;
