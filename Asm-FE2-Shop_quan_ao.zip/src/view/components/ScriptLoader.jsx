import { useEffect } from "react";

const scripts = [
  "/assets/admin/js/chart.min.js",
  "/assets/admin/js/easing.js",
  "/assets/admin/js/easing.min.js",
  "/assets/admin/js/main.js",
  "/assets/admin/js/moment-timezone.min.js",
  "/assets/admin/js/moment.min.js",
  "/assets/admin/js/owl.carousel.js",
  "/assets/admin/js/owl.carousel.min.js",
  "/assets/admin/js/tempusdominus-bootstrap-4.js",
  "/assets/admin/js/tempusdominus-bootstrap-4.min.js",
  "/assets/admin/js/waypoints.min.js",
];


const ScriptLoader = () => {
  useEffect(() => {
    scripts.forEach((src) => {
      if (!document.querySelector(`script[src="${src}"]`)) {
        const script = document.createElement("script");
        script.src = src;
        script.async = true;
        document.body.appendChild(script);
      }
    });
  }, []);

  return null; // Không cần render gì cả
};

export default ScriptLoader;
