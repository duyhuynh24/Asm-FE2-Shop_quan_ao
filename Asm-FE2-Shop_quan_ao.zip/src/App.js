import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./assets/admin/css/bootstrap.min.css";
import "./assets/admin/css/style.css";
import "./assets/admin/scss/bootstrap.scss"; 
import ScriptLoader from './view/components/ScriptLoader';

function App() {
  return (
    <BrowserRouter>
      <Routes>

      </Routes>
      <ScriptLoader />
    </BrowserRouter>
  );
}

export default App;
